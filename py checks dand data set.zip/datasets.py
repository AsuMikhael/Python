"""One dataset per dashboard visual (the SQL reporting views bi.v_*), and export to CSV or Excel."""
from __future__ import annotations

import os
from collections import OrderedDict
from typing import Callable, Dict, Optional

import pandas as pd

from .helpers import sdiv
from .measures import *  # noqa: F401,F403 (all measure functions)
from .measures import (m_city_network, m_customer_overall, m_customer_scorecard, m_delivery_by, m_driver_by_tenure, m_driver_overall,
                       m_driver_scorecard, m_finance, m_finance_by, m_fleet_overall, m_fuel_by, m_fuel_by_state, m_fuel_overall, m_idle_band,
                       m_kpi_exec, m_lane_matrix, m_latest_incidents, m_loads_daily, m_maintenance_by, m_margin_bridge, m_revenue_trend,
                       m_route_scorecard, m_safety_by, m_safety_by_driver, m_safety_overall, m_scenario, m_service, m_trailer_util_by_type,
                       m_truck_scorecard)
from .measures._common import add_dates, true_
from .params import Params
from .scope import Scope, scope_delivery, scope_load
from .star import Star


def _facility_map(star, sc, p):
    d = m_delivery_by(star, "facility", sc, p)
    return d.merge(star.dim_facility[["facility_id", "latitude", "longitude"]].astype({"facility_id": "string"}), left_on="dim_key", right_on="facility_id", how="left").drop(columns="facility_id")


def _weekday_month(star, sc, p):
    d = add_dates(star, scope_delivery(star, sc))
    d = d.assign(_n=d["is_delivery"].astype(int), _ok=(d["is_delivery"] & true_(d["on_time_flag"])).astype(int))
    g = d.groupby(["day_number", "day_name", "month_number", "month_name"], dropna=False)[["_n", "_ok"]].sum().reset_index()
    return g.assign(total_deliveries=g["_n"], on_time_pct=sdiv(g["_ok"], g["_n"])).drop(columns=["_n", "_ok"])


def _cost_by_model_year(star, sc, p):
    m = m_maintenance_by(star, "model_year", sc, p)[["dim_key", "maintenance_cost"]]
    f = m_finance_by(star, "model_year", sc, p)[["dim_key", "total_miles"]]
    out = m.merge(f, on="dim_key", how="left").rename(columns={"dim_key": "model_year"})
    out["maint_cost_per_mile_actual"] = sdiv(out["maintenance_cost"], out["total_miles"])
    return out


def _customers_by_type(star, sc, p):
    s = scope_load(star, sc).merge(star.dim_customer[["customer_id", "customer_type", "primary_freight_type"]], on="customer_id", how="left")
    g = s.groupby(["customer_type", "primary_freight_type"], dropna=False)
    return pd.DataFrame({"customer_revenue": g["revenue"].sum(min_count=1), "customer_margin": g["gross_profit"].sum(min_count=1), "load_count": g.size()}).reset_index()


def _top5_monthly(star, sc, p):
    top = m_customer_scorecard(star, sc, p)
    top = top[top["customer_rank"].astype("float64") <= 5][["customer_id", "customer_name"]]
    s = add_dates(star, scope_load(star, sc)).merge(top, on="customer_id", how="inner")
    return s.groupby(["customer_name", "year", "month_number", "year_month"], dropna=False)["revenue"].sum(min_count=1).rename("customer_revenue").reset_index()


def _util(star, sc, p):
    t = m_truck_scorecard(star, sc, p)[["truck_id", "fleet_utilization_pct"]]
    t["utilization_status_color"] = [None] * len(t)
    from .helpers import f_color_utilization
    t["utilization_status_color"] = f_color_utilization(t["fleet_utilization_pct"], p)
    return t


def _drivers_monthly(star, sc, p):
    f = m_finance_by(star, "year_month", sc.with_(driver=sc.driver), p)[["dim_key", "total_miles"]]
    d = m_delivery_by(star, "year_month", sc, p)[["dim_key", "on_time_pct"]].rename(columns={"on_time_pct": "driver_on_time_pct"})
    return f.merge(d, on="dim_key", how="left").rename(columns={"dim_key": "year_month"})


DATASETS: "OrderedDict[str, Callable[[Star, Scope, Params], pd.DataFrame]]" = OrderedDict([
    ("v_exec_kpis", lambda s, c, p: m_kpi_exec(s, c, p)),
    ("v_exec_revenue_trend", lambda s, c, p: m_revenue_trend(s, c, p)),
    ("v_exec_top_customers", lambda s, c, p: m_customer_scorecard(s, c, p).head(10)),
    ("v_exec_routes", lambda s, c, p: m_route_scorecard(s, c, p)),
    ("v_exec_truck_utilization", _util),
    ("v_exec_facility_map", _facility_map),
    ("v_ops_kpis", lambda s, c, p: m_service(s, c, p)),
    ("v_ops_daily", lambda s, c, p: m_loads_daily(s, c, p)),
    ("v_ops_booking_mix", lambda s, c, p: m_finance_by(s, "booking_type", c, p)[["dim_label", "load_count", "delivery_volume_share"]].rename(columns={"dim_label": "booking_type"})),
    ("v_ops_ontime_trend", lambda s, c, p: m_delivery_by(s, "year_month", c, p)),
    ("v_ops_ontime_weekday_month", _weekday_month),
    ("v_ops_facilities", _facility_map),
    ("v_ops_detention_buckets", lambda s, c, p: m_delivery_by(s, "detention_bucket", c, p)),
    ("v_ops_late_by_customer", lambda s, c, p: m_delivery_by(s, "customer", c, p)[["dim_label", "late_deliveries"]].rename(columns={"dim_label": "customer_name"})),
    ("v_drivers_kpis", lambda s, c, p: m_driver_overall(s, c, p)),
    ("v_drivers_scorecard", lambda s, c, p: m_driver_scorecard(s, c, p)),
    ("v_drivers_monthly", _drivers_monthly),
    ("v_drivers_by_tenure", lambda s, c, p: m_driver_by_tenure(s, c, p)),
    ("v_drivers_idle_band", lambda s, c, p: m_idle_band(s, c, p)),
    ("v_fleet_kpis", lambda s, c, p: m_fleet_overall(s, c, p)),
    ("v_fleet_trucks", lambda s, c, p: m_truck_scorecard(s, c, p)),
    ("v_fleet_cost_by_month", lambda s, c, p: m_maintenance_by(s, "year_month", c, p)),
    ("v_fleet_cost_by_type", lambda s, c, p: m_maintenance_by(s, "maintenance_type", c, p)),
    ("v_fleet_cost_by_model_year", _cost_by_model_year),
    ("v_fleet_trailers", lambda s, c, p: m_trailer_util_by_type(s, c, p)),
    ("v_fuel_kpis", lambda s, c, p: m_fuel_overall(s, c, p)),
    ("v_fuel_by_month", lambda s, c, p: m_fuel_by(s, "year_month", c, p)),
    ("v_fuel_by_state", lambda s, c, p: m_fuel_by_state(s, c, p)),
    ("v_fuel_mpg_by_model_year", lambda s, c, p: m_finance_by(s, "model_year", c, p)[["dim_key", "avg_mpg", "cost_per_mile"]].rename(columns={"dim_key": "model_year"})),
    ("v_safety_kpis", lambda s, c, p: m_safety_overall(s, c, p)),
    ("v_safety_by_type", lambda s, c, p: m_safety_by(s, "incident_type", c, p)),
    ("v_safety_by_month", lambda s, c, p: m_safety_by(s, "year_month", c, p)),
    ("v_safety_by_driver", lambda s, c, p: m_safety_by_driver(s, c, p)),
    ("v_safety_latest", lambda s, c, p: m_latest_incidents(s, c, p)),
    ("v_customers_kpis", lambda s, c, p: m_customer_overall(s, c, p)),
    ("v_customers_scorecard", lambda s, c, p: m_customer_scorecard(s, c, p)),
    ("v_customers_by_type", _customers_by_type),
    ("v_customers_top5_monthly", _top5_monthly),
    ("v_routes_kpis", lambda s, c, p: m_finance(s, c, p)),
    ("v_routes_scorecard", lambda s, c, p: m_route_scorecard(s, c, p)),
    ("v_routes_lanes", lambda s, c, p: m_lane_matrix(s, c, p)),
    ("v_routes_network", lambda s, c, p: m_city_network(s, c, p)),
    ("v_routes_bridge", lambda s, c, p: m_margin_bridge(s, c, p)),
    ("v_routes_scenario", lambda s, c, p: m_scenario(s, c, p)),
])

PAGES = {"Executive": "v_exec_", "Operations": "v_ops_", "Drivers": "v_drivers_", "Fleet": "v_fleet_", "Fuel & Safety": ("v_fuel_", "v_safety_"),
         "Customers": "v_customers_", "Routes": "v_routes_"}


def build_datasets(star: Star, scope: Scope = Scope(), params: Optional[Params] = None, only: Optional[str] = None) -> Dict[str, pd.DataFrame]:
    """Build every dashboard dataset (or the ones whose name starts with `only`) for a scope."""
    p = params or Params()
    return {n: fn(star, scope, p) for n, fn in DATASETS.items() if only is None or n.startswith(only)}


def export_datasets(datasets: Dict[str, pd.DataFrame], directory: str, fmt: str = "csv") -> str:
    """Write the datasets as one CSV per dataset, or as one Excel workbook (needs openpyxl). Returns the path written."""
    os.makedirs(directory, exist_ok=True)
    if fmt == "csv":
        for n, df in datasets.items():
            df.to_csv(os.path.join(directory, f"{n}.csv"), index=False)
        return directory
    if fmt == "xlsx":
        path = os.path.join(directory, "datasets.xlsx")
        with pd.ExcelWriter(path) as xw:
            for n, df in datasets.items():
                df.to_excel(xw, sheet_name=n[2:33] if n.startswith("v_") else n[:31], index=False)
        return path
    raise ValueError("fmt must be 'csv' or 'xlsx'")
