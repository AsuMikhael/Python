"""Data quality, internal consistency and reconciliation checks."""
from __future__ import annotations

from typing import Dict, Mapping, Optional, Tuple

import numpy as np
import pandas as pd

from .config import DRIVER_UNKNOWN, REFERENCE_EXPECTED
from .helpers import sdiv
from .measures import (m_city_network, m_customer_overall, m_customer_scorecard, m_driver_overall, m_driver_scorecard, m_finance,
                       m_finance_by, m_lane_matrix, m_margin_bridge, m_route_scorecard, m_safety_overall, m_scenario, m_service)
from .params import Params
from .scope import Scope
from .star import Star


def data_quality(source: Mapping[str, pd.DataFrame], star: Star) -> pd.DataFrame:
    """Gaps found while building the report (the SQL view bi.v_dq): returns metric and value."""
    loads, trips, fuel = source["loads"], source["trips"], source["fuel_purchases"]
    unknown_trips = trips[trips["driver_id"] == DRIVER_UNKNOWN]
    unknown_rev = loads[loads["load_id"].isin(unknown_trips["load_id"])]["revenue"].sum()
    mr = star.month_maint_ratio
    rows = [
        ("loads without a trip", int((~loads["load_id"].isin(trips["load_id"])).sum())),
        ("trips without a load", int((~trips["load_id"].isin(loads["load_id"])).sum())),
        ("trips under DRV_UNKNOWN", len(unknown_trips)), ("revenue under DRV_UNKNOWN", float(unknown_rev)),
        ("fuel rows with no trip_id", int(fuel["trip_id"].isna().sum())), ("fuel cost with no trip_id", float(fuel.loc[fuel["trip_id"].isna(), "total_cost"].sum())),
        ("fuel rows with blank state", int(fuel["location_state"].isna().sum())),
        ("safety rows with no trip_id", int(source["safety_incidents"]["trip_id"].isna().sum())),
        ("delivery rows with no trip_id", int(source["delivery_events"]["trip_id"].isna().sum())),
        ("trucks with blank model_year", int(source["trucks"]["model_year"].isna().sum())),
        ("drivers with no hire_date", int(source["drivers"]["hire_date"].isna().sum())),
        ("distinct account_status values", int(source["customers"]["account_status"].nunique())),
        ("distinct load_status values", int(loads["load_status"].nunique())),
        ("distinct event_type values", int(source["delivery_events"]["event_type"].nunique())),
        ("months with maintenance but no miles", int((mr["maintenance_cost"].notna() & ~(mr["miles"].fillna(0) > 0)).sum())),
        ("trips shared by more than one load", int(trips["load_id"].duplicated().sum())),
    ]
    return pd.DataFrame(rows, columns=["metric", "value"])


def orphan_check(star: Star) -> pd.DataFrame:
    """Keys that would violate the foreign keys (the SQL view bi.v_orphan_check)."""
    f = star.fact_load_trip
    pairs = [("fact_load_trip.customer_id", f["customer_id"], star.dim_customer["customer_id"]),
             ("fact_load_trip.route_id", f["route_id"], star.dim_route["route_id"]),
             ("fact_load_trip.driver_id", f["driver_id"], star.dim_driver["driver_id"]),
             ("fact_load_trip.truck_id", f["truck_id"], star.dim_truck["truck_id"]),
             ("fact_load_trip.trailer_id", f["trailer_id"], star.dim_trailer["trailer_id"]),
             ("fact_load_trip.load_date", f["load_date"], star.dim_date["full_date"]),
             ("fact_delivery_event.facility_id", star.fact_delivery_event["facility_id"], star.dim_facility["facility_id"]),
             ("fact_maintenance_event.truck_id", star.fact_maintenance_event["truck_id"], star.dim_truck["truck_id"]),
             ("fact_maintenance_event.maintenance_date", star.fact_maintenance_event["maintenance_date"], star.dim_date["full_date"]),
             ("fact_truck_month.truck_id", star.fact_truck_month["truck_id"], star.dim_truck["truck_id"]),
             ("fact_driver_month.driver_id", star.fact_driver_month["driver_id"], star.dim_driver["driver_id"])]
    rows = [(name, int((child.notna() & ~child.isin(parent)).sum())) for name, child, parent in pairs]
    return pd.DataFrame(rows, columns=["fk", "orphans"])


def _close(a: float, b: float, tol: float = 1e-6) -> bool:
    return bool(np.isclose(a, b, rtol=1e-9, atol=tol))


def consistency_checks(star: Star, params: Optional[Params] = None) -> pd.DataFrame:
    """Identities that hold for ANY data. A failure means a bug or a broken source (not a different dataset)."""
    p = params or Params()
    f = star.fact_load_trip
    tot = m_finance(star, Scope(), p).iloc[0]
    checks = []

    def add(name: str, ok: bool, detail: str = "") -> None:
        checks.append(dict(check=name, passed=bool(ok), detail=detail))

    add("revenue equals the sum of load revenue", _close(tot["total_revenue"], f["revenue"].sum()))
    add("gross profit = revenue - fuel - allocated maintenance",
        _close(tot["gross_profit"], f["revenue"].sum() - f["fuel_cost"].sum() - f["maint_alloc"].sum(), 1e-4))
    mr = star.month_maint_ratio
    covered = mr[mr["miles"].fillna(0) > 0]["maintenance_cost"].sum()
    add("allocated maintenance equals maintenance in months that have miles", _close(f["maint_alloc"].sum(), covered, 1e-4),
        f"allocated {f['maint_alloc'].sum():,.2f} vs {covered:,.2f}")
    for dim in ("year", "year_month", "customer", "route", "booking_type", "truck", "driver"):
        by = m_finance_by(star, dim, Scope(), p)
        add(f"m_finance_by({dim}) sums to the total",
            _close(by["total_revenue"].sum(), tot["total_revenue"], 1e-4) and _close(by["load_count"].sum(), tot["load_count"]) and
            _close(by["gross_profit"].sum(), tot["gross_profit"], 1e-4))
    add("driver scorecard plus DRV_UNKNOWN equals revenue with a driver",
        _close(m_driver_scorecard(star, Scope(), p)["revenue_trip_based"].sum() + f.loc[f["driver_id"] == DRIVER_UNKNOWN, "revenue"].sum(),
               f.loc[f["driver_id"].notna(), "revenue"].sum(), 1e-4))
    add("customer scorecard sums to the total", _close(m_customer_scorecard(star, Scope(), p)["customer_revenue"].sum(), tot["total_revenue"], 1e-4))
    add("route scorecard sums to the total", _close(m_route_scorecard(star, Scope(), p)["route_revenue"].sum(), tot["total_revenue"], 1e-4))
    add("lane matrix sums to the total", _close(m_lane_matrix(star, Scope(), p)["total_revenue"].sum(), tot["total_revenue"], 1e-4))
    net = m_city_network(star, Scope(), p)
    add("loads out equal loads in equal loads", int(net["outbound_loads"].sum()) == int(net["inbound_loads"].sum()) == int(tot["load_count"]))
    br = m_margin_bridge(star, Scope(), p).set_index("item")["margin_bridge_value"]
    add("margin bridge: revenue + fuel + maintenance = gross profit", _close(br["Revenue"] + br["Fuel"] + br["Maintenance"], br["Gross Profit"], 1e-4))
    sc = m_scenario(star, Scope(), Params()).iloc[0]
    add("scenario at default parameters equals the baseline", _close(sc["profit_scenario"], sc["gross_profit"], 1e-4) and _close(sc["profit_scenario_delta"], 0, 1e-4))
    sv = m_service(star, Scope(), p).iloc[0]
    add("on-time deliveries never exceed deliveries", sv["on_time_deliveries"] <= sv["total_deliveries"])
    cs = m_customer_scorecard(star, Scope(), p)
    add("Pareto: cumulative share is monotone and ends at 100%",
        bool(cs["cumulative_revenue_pct"].is_monotonic_increasing) and _close(cs["cumulative_revenue_pct"].max(), 1.0, 1e-9))
    return pd.DataFrame(checks)


def reconcile(star: Star, expected: Optional[Dict[str, Tuple[float, float]]] = None, params: Optional[Params] = None) -> pd.DataFrame:
    """Compare results with figures verified in the Power BI report (expected = {measure: (value, tolerance)}).

    Run with no filters and default parameters. The default expectations belong to the reference dataset.
    """
    p = params or Params()
    expected = expected if expected is not None else REFERENCE_EXPECTED
    pools = {}
    for df in (m_finance(star, Scope(), p), m_service(star, Scope(), p), m_driver_overall(star, Scope(), p),
               m_customer_overall(star, Scope(), p), m_safety_overall(star, Scope(), p)):
        for c in df.columns:
            pools.setdefault(c, float(pd.to_numeric(df.iloc[0][c], errors="coerce")))
    rows = []
    for name, (exp, tol) in expected.items():
        act = pools.get(name, np.nan)
        rows.append(dict(check=name, expected=exp, actual=act, tolerance=tol, passed=bool(abs(act - exp) <= tol) if pd.notna(act) else False))
    return pd.DataFrame(rows)
