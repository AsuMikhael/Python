import math
import unittest

import numpy as np
import pandas as pd

from support import star  # noqa: F401 (sets the import path)
from logistics_analytics import helpers as h
from logistics_analytics.config import BAD, CAUTION, GOOD, LIGHT_GOOD, NO_DATA
from logistics_analytics.params import Params, parameter_values, snake


class TestSdiv(unittest.TestCase):
    def test_scalar(self):
        self.assertEqual(h.sdiv(6, 3), 2.0)
        self.assertTrue(math.isnan(h.sdiv(1, 0)))
        self.assertTrue(math.isnan(h.sdiv(1, np.nan)))
        self.assertTrue(math.isnan(h.sdiv(np.nan, 2)))

    def test_series_keeps_index_and_handles_zero(self):
        a = pd.Series([1.0, 2.0, 3.0], index=list("xyz"))
        b = pd.Series([2.0, 0.0, np.nan], index=list("xyz"))
        out = h.sdiv(a, b)
        self.assertEqual(list(out.index), list("xyz"))
        self.assertEqual(out["x"], 0.5)
        self.assertTrue(out[["y", "z"]].isna().all())

    def test_nullable_dtypes(self):
        out = h.sdiv(pd.Series([4, pd.NA], dtype="Int64"), pd.Series([2, 2], dtype="Int64"))
        self.assertEqual(out.iloc[0], 2.0)
        self.assertTrue(np.isnan(out.iloc[1]))


class TestColoursAndStatus(unittest.TestCase):
    def test_on_time_color(self):
        self.assertEqual(h.f_color_on_time(0.96), GOOD)
        self.assertEqual(h.f_color_on_time(0.92), CAUTION)
        self.assertEqual(h.f_color_on_time(0.80), BAD)
        self.assertEqual(h.f_color_on_time(np.nan), NO_DATA)
        self.assertEqual(h.f_color_on_time(0.56, Params(on_time_target=0.80)), BAD)
        self.assertEqual(h.f_color_on_time(pd.Series([0.96, np.nan])).tolist(), [GOOD, NO_DATA])

    def test_utilization_color(self):
        self.assertEqual(h.f_color_utilization(0.85), GOOD)
        self.assertEqual(h.f_color_utilization(0.75), CAUTION)
        self.assertEqual(h.f_color_utilization(0.5), BAD)

    def test_driver_score_color_is_relative(self):
        self.assertEqual(h.f_color_driver_score(70.0, 66.0), GOOD)
        self.assertEqual(h.f_color_driver_score(67.0, 66.0), LIGHT_GOOD)
        self.assertEqual(h.f_color_driver_score(65.0, 66.0), CAUTION)
        self.assertEqual(h.f_color_driver_score(60.0, 66.0), BAD)

    def test_service_and_churn_status(self):
        self.assertEqual(h.f_service_status(100), "Overdue")
        self.assertEqual(h.f_service_status(80), "Due soon")
        self.assertEqual(h.f_service_status(50), "OK")
        self.assertEqual(h.f_service_status(np.nan), "No history")
        self.assertEqual(h.f_service_status(50, Params(service_interval_days=30)), "Overdue")
        self.assertEqual(h.f_churn_status(100), "At risk")
        self.assertEqual(h.f_churn_status(70), "Watch")
        self.assertEqual(h.f_churn_status(10), "Active")
        self.assertEqual(h.f_churn_status(np.nan), "No loads")
        self.assertEqual(h.f_color_service_status("Overdue"), BAD)
        self.assertEqual(h.f_color_churn("Active"), GOOD)

    def test_abc_and_route_tier_and_bucket(self):
        self.assertEqual([h.f_abc_class(v) for v in (0.5, 0.8, 0.9, 0.99)], ["A", "A", "B", "C"])
        self.assertEqual([h.f_route_tier(v) for v in (0.03, 0.0, -0.03, np.nan)], ["Above fleet", "In line", "Below fleet", "No data"])
        self.assertEqual([h.f_driver_bucket(v) for v in (90, 75, 60, 10)], ["Elite", "Solid", "Coach", "At risk"])
        self.assertIsNone(h.f_driver_bucket(np.nan))

    def test_cost_per_mile_and_price_variance_colors(self):
        self.assertEqual(h.f_color_cost_per_mile(0.1, 0.1), GOOD)
        self.assertEqual(h.f_color_cost_per_mile(0.11, 0.1), CAUTION)
        self.assertEqual(h.f_color_cost_per_mile(0.13, 0.1), BAD)
        self.assertEqual(h.f_color_price_variance(-0.01), GOOD)
        self.assertEqual(h.f_color_price_variance(0.001), CAUTION)
        self.assertEqual(h.f_color_price_variance(0.01), BAD)


class TestScores(unittest.TestCase):
    def test_service_score(self):
        self.assertAlmostEqual(h.f_service_score(1, 0, 0), 100.0)
        self.assertAlmostEqual(h.f_service_score(0, 1, 1), 0.0)
        self.assertAlmostEqual(h.f_service_score(0.5, 0.1, 0.5), 58.0)
        self.assertAlmostEqual(h.f_service_score(np.nan, 0.0, 0.0), 40.0)   # missing on-time counts as 0

    def test_driver_score_matches_hand_calculation(self):
        # on-time .56, MPG = target, idle .28 (above the 25% cap), 1.4 incidents per million miles
        self.assertAlmostEqual(h.f_driver_score(0.56, 6.5, 0.28, 1.4), 100 * (0.4 * 0.56 + 0.25 * 1 + 0.15 * 0 + 0.2 * 0.86))
        self.assertTrue(math.isnan(h.f_driver_score(np.nan, 6.5, 0.2, 1.0)))
        self.assertTrue(math.isnan(h.f_driver_score(0.5, np.nan, 0.2, 1.0)))
        full = h.f_driver_score(0.5, 6.5, np.nan, np.nan)                       # missing idle and safety count as perfect
        self.assertAlmostEqual(full, 100 * (0.4 * 0.5 + 0.25 + 0.15 + 0.2))
        self.assertAlmostEqual(h.f_driver_score(0.56, 6.5, 0.28, 1.4, Params(target_mpg=9)), 100 * (0.4 * 0.56 + 0.25 * (6.5 / 9) + 0.2 * 0.86))

    def test_vectorised(self):
        s = h.f_driver_score(pd.Series([0.5, 0.6]), pd.Series([6.0, 7.0]), pd.Series([0.2, 0.3]), pd.Series([0.0, 5.0]))
        self.assertIsInstance(s, pd.Series)
        self.assertEqual(len(s), 2)
        self.assertTrue(((s >= 0) & (s <= 100)).all())


class TestParams(unittest.TestCase):
    def test_defaults_and_set(self):
        p = Params()
        self.assertEqual(p.get("top_n"), 10)
        p.set("top_n", 18)
        self.assertEqual(p.get("top_n"), 18)
        p.set("top_n", None)
        self.assertEqual(p.get("top_n"), 10)

    def test_validation(self):
        with self.assertRaises(ValueError):
            Params(top_n=99)
        with self.assertRaises(KeyError):
            Params(not_a_parameter=1)
        with self.assertRaises(KeyError):
            Params().get("nope")

    def test_reset_and_frame(self):
        p = Params(top_n=5, target_mpg=7.5)
        self.assertEqual(len(p.as_frame()), 11)
        p.reset()
        self.assertEqual(p.get("target_mpg"), 6.5)
        self.assertIn("changed", repr(Params(top_n=5)))

    def test_value_measures(self):
        vm = Params(top_n=18).value_measures()
        self.assertEqual(len(vm), 11)
        self.assertEqual(vm["top_n_value"], 18)
        self.assertEqual(vm["target_mpg_value"], 6.5)
        self.assertEqual(list(parameter_values().columns), list(Params().value_measures()))

    def test_snake_names(self):
        cases = {"On-Time %": "on_time_pct", "Revenue (Trip-based)": "revenue_trip_based", "7 Day Avg": "loads_booked_7day_avg",
                 "% On-time Deliveries": "pct_on_time_deliveries", "Maint Cost per Mile (actual)": "maint_cost_per_mile_actual",
                 "Incidents per 1M Miles": "incidents_per_1m_miles", "Total Revenue": "total_revenue", "Fleet Age (yrs)": "fleet_age_yrs"}
        for k, v in cases.items():
            self.assertEqual(snake(k), v, k)


if __name__ == "__main__":
    unittest.main()
