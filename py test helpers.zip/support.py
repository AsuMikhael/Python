"""Shared fixtures: a small synthetic source and its star, built once."""
import os
import sys
from functools import lru_cache

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))

from logistics_analytics.star import build_star  # noqa: E402
from logistics_analytics.synthetic import make_synthetic_source  # noqa: E402


@lru_cache(maxsize=1)
def source():
    return make_synthetic_source(seed=7, n_loads=800)


@lru_cache(maxsize=1)
def star():
    return build_star(source())
