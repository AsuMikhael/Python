"""Analysis: descriptive (what happened), diagnostic (why) and predictive (what is likely next).

The queries mirror sql/10_analysis_queries.sql. Predictive functions are transparent trend and ratio models
(numpy least squares, recency against rhythm, miles against service interval): indications, not guarantees.
"""
from __future__ import annotations

from typing import Dict, Optional

import numpy as np
import pandas as pd

from .config import DRIVER_UNKNOWN
from .helpers import sdiv
from .measures import (m_city_network, m_customer_scorecard, m_delivery_by, m_driver_scorecard, m_finance, m_finance_by, m_fuel_by,
                       m_fuel_by_state, m_revenue_trend, m_route_scorecard, m_safety_by)
from .params import Params
from .scope import Scope, scope_load
from .star import Star


# =========================================================================== descriptive
def a1_revenue_trend(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Revenue, profit and margin by month with prior year, MoM, YTD and rolling 12 months."""
    return m_revenue_trend(star, scope, params)[["year_month", "total_revenue", "gross_profit", "gross_margin", "revenue_py", "revenue_yoy_pct",
                                                 "revenue_mom_pct", "revenue_ytd", "revenue_rolling_12m"]]


def a2_headline(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Headline figures for a window."""
    return m_finance(star, scope, params)[["total_revenue", "gross_profit", "gross_margin", "load_count", "total_miles", "revenue_per_mile",
                                           "route_cost_per_mile", "fuel_cost", "avg_mpg"]]


def a3_revenue_by_customer_type(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Revenue and margin by customer type and freight type."""
    s = scope_load(star, scope).merge(star.dim_customer[["customer_id", "customer_type", "primary_freight_type"]], on="customer_id", how="left")
    g = s.groupby(["customer_type", "primary_freight_type"], dropna=False)
    out = pd.DataFrame({"revenue": g["revenue"].sum(), "gross_profit": g["gross_profit"].sum(), "loads": g.size()}).reset_index()
    out["gross_margin"] = sdiv(out["gross_profit"], out["revenue"])
    return out.sort_values("revenue", ascending=False).reset_index(drop=True)


def a4_pareto(star: Star, scope: Scope = Scope(), params: Optional[Params] = None, top_n: int = 18) -> pd.DataFrame:
    """Customer concentration: the Pareto table. The share of the top N customers is in `attrs['top_n_share_pct']`."""
    cs = m_customer_scorecard(star, scope, params)
    out = cs[["customer_rank", "customer_name", "customer_revenue", "cumulative_revenue_pct", "abc_class"]].copy()
    out["cumulative_pct"] = (out["cumulative_revenue_pct"] * 100).round(1)
    out.attrs["top_n_share_pct"] = round(float(sdiv(cs.loc[cs["customer_rank"].astype("float64") <= top_n, "customer_revenue"].sum(), cs["customer_revenue"].sum())) * 100, 1)
    return out.drop(columns="cumulative_revenue_pct")


def a5_fuel_by_state(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Fuel spend and price by state."""
    return m_fuel_by_state(star, scope, params)[["location_state", "fuel_cost", "fuel_gallons", "avg_price_per_gallon", "state_price_vs_fleet_avg"]]


def a6_safety(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Dict[str, pd.DataFrame]:
    """Incidents by type, and by year with the rate per million miles."""
    by_type = m_safety_by(star, "incident_type", scope, params)[["dim_label", "safety_incidents", "at_fault_incidents", "at_fault_pct", "total_claims"]]
    by_year = m_safety_by(star, "year", scope, params)[["dim_key", "safety_incidents"]].merge(
        m_finance_by(star, "year", scope, params)[["dim_key", "total_miles"]], on="dim_key", how="left")
    by_year["incidents_per_1m_miles"] = sdiv(by_year["safety_incidents"], by_year["total_miles"]) * 1_000_000
    return {"by_type": by_type.rename(columns={"dim_label": "incident_type"}), "by_year": by_year.rename(columns={"dim_key": "year"})}


def a7_network_balance(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Loads out and in by city. Positive balance: more loads leave than arrive."""
    return m_city_network(star, scope, params).sort_values("lane_balance_pct", ascending=False).reset_index(drop=True)


# =========================================================================== diagnostic
def b1_cost_structure(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Contribution margin versus an illustrative full-cost margin (driver pay uses the Driver Pay per Mile parameter)."""
    f = m_finance(star, scope, params).iloc[0]
    return pd.DataFrame([dict(
        total_revenue=f["total_revenue"], fuel_cost=f["fuel_cost"], maintenance_cost_allocated=f["maintenance_cost_allocated"], gross_profit=f["gross_profit"],
        contribution_margin_pct=round(f["gross_margin"] * 100, 1), driver_cost=f["driver_cost"],
        margin_after_driver_pay_pct=round(float(sdiv(f["gross_profit"] - f["driver_cost"], f["total_revenue"])) * 100, 1),
        fuel_share_of_revenue_pct=round(float(sdiv(f["fuel_cost"], f["total_revenue"])) * 100, 1))])


def b2_driver_spread(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Are drivers really alike? Spread of the main driver metrics (coefficient of variation near 0 means nearly identical)."""
    sc = m_driver_scorecard(star, scope, params)
    rows = []
    for m in ("revenue_trip_based", "avg_mpg", "idle_pct", "driver_on_time_pct"):
        v = sc[m].dropna().astype(float)
        rows.append(dict(metric=m, min_value=v.min(), max_value=v.max(), mean=v.mean(), stddev=v.std(ddof=0), coefficient_of_variation=float(sdiv(v.std(ddof=0), v.mean()))))
    return pd.DataFrame(rows)


def b3_fuel_price_variation(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Does fuel price vary by month or by state? Compare the spread of the two."""
    rows = []
    for label, dim in (("by month", "year_month"), ("by state", "state")):
        d = m_fuel_by(star, dim, scope, params)
        d = d[d["dim_key"].notna()]
        v = d["avg_price_per_gallon"].astype(float)
        rows.append(dict(grouping=label, groups=len(d), min_price=v.min(), max_price=v.max(), spread=v.max() - v.min(), stddev=v.std(ddof=0)))
    return pd.DataFrame(rows)


def b4_ontime_hotspots(star: Star, scope: Scope = Scope(), params: Optional[Params] = None, min_deliveries: int = 50) -> Dict[str, pd.DataFrame]:
    """Where does on-time delivery fail? Weakest facilities, on-time by weekday, customers with most late deliveries."""
    fac = m_delivery_by(star, "facility", scope, params)
    fac = fac[fac["total_deliveries"] >= min_deliveries].sort_values("on_time_pct").head(10)[["dim_label", "total_deliveries", "on_time_pct", "average_detention"]]
    wk = m_delivery_by(star, "day_name", scope, params).sort_values("dim_key")[["dim_label", "total_deliveries", "on_time_pct"]]
    cu = m_delivery_by(star, "customer", scope, params)
    cu = cu[cu["total_deliveries"] >= min_deliveries].sort_values("late_deliveries", ascending=False).head(10)[["dim_label", "total_deliveries", "late_deliveries", "on_time_pct"]]
    return {"facilities": fac.rename(columns={"dim_label": "facility"}), "weekdays": wk.rename(columns={"dim_label": "weekday"}),
            "customers": cu.rename(columns={"dim_label": "customer"})}


def b5_detention_correlation(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Does detention explain lateness? Correlation across facilities (about -1 = yes, about 0 = no)."""
    d = m_delivery_by(star, "facility", scope, params)
    d = d[d["dim_key"].notna()][["average_detention", "on_time_pct"]].astype(float).dropna()
    corr = float(d["average_detention"].corr(d["on_time_pct"])) if len(d) > 2 else np.nan
    return pd.DataFrame([dict(corr_detention_vs_on_time=round(corr, 3) if pd.notna(corr) else np.nan, facilities=len(d))])


def b6_unknown_driver_share(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """How much revenue has no named driver (DRV_UNKNOWN)?"""
    s = scope_load(star, scope)
    u = s[s["driver_id"] == DRIVER_UNKNOWN]
    return pd.DataFrame([dict(unknown_trips=int(u["trip_id"].count()), unknown_revenue=u["revenue"].sum(),
                              share_of_revenue_pct=round(float(sdiv(u["revenue"].sum(), s["revenue"].sum())) * 100, 2))])


def b7_allocation_reconciliation(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Does the maintenance allocation reconcile month by month? difference should be 0 for every month with miles."""
    f = star.fact_load_trip
    alloc = f.assign(month_start=f["load_date"].dt.to_period("M").dt.to_timestamp()).groupby("month_start")["maint_alloc"].sum().rename("allocated")
    r = star.month_maint_ratio.set_index("month_start")[["maintenance_cost"]].join(alloc).fillna({"allocated": 0.0})
    r["difference"] = r["maintenance_cost"].fillna(0) - r["allocated"]
    return r.round(2).reset_index()


def b8_margin_spread(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Margin spread across customers and routes (after the miles-based maintenance allocation)."""
    c = m_customer_scorecard(star, scope, params)["customer_margin_pct"].astype(float)
    r = m_route_scorecard(star, scope, params)["gross_margin"].astype(float)
    rows = [dict(level=n, n=len(v), min_margin_pct=round(v.min() * 100, 1), max_margin_pct=round(v.max() * 100, 1), stddev_pts=round(v.std(ddof=0) * 100, 2))
            for n, v in (("customers", c), ("routes", r))]
    return pd.DataFrame(rows)


# =========================================================================== predictive
def c1_revenue_forecast(star: Star, scope: Scope = Scope(), params: Optional[Params] = None, months: int = 6) -> pd.DataFrame:
    """Linear trend of monthly revenue (least squares) and a projection. A low r2 means read it as a flat run-rate."""
    t = m_revenue_trend(star, scope, params)
    y = t["total_revenue"].to_numpy(dtype=float)
    if len(y) < 3:
        raise ValueError("Need at least 3 months of revenue to fit a trend")
    x = np.arange(1, len(y) + 1, dtype=float)
    slope, intercept = np.polyfit(x, y, 1)
    r2 = float(np.corrcoef(x, y)[0, 1] ** 2) if y.std() > 0 else 0.0
    last = pd.Period(t["year_month"].iloc[-1], freq="M")
    ks = np.arange(len(y) + 1, len(y) + months + 1)
    return pd.DataFrame({"month": [(last + int(k - len(y))).strftime("%Y-%m") for k in ks], "projected_revenue": (intercept + slope * ks).round(0),
                         "monthly_trend": round(float(slope), 0), "r2": round(r2, 3)})


def c2_seasonality_index(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Average revenue of each calendar month against the overall monthly average (needs two years to mean much)."""
    t = m_revenue_trend(star, scope, params)
    m = t.groupby(["month_number", "month_name"])["total_revenue"].mean().rename("avg_revenue").reset_index()
    m["seasonality_index"] = (m["avg_revenue"] / m["avg_revenue"].mean()).round(3)
    return m.sort_values("month_number").reset_index(drop=True)[["month_name", "avg_revenue", "seasonality_index"]]


def c3_churn_risk(star: Star, scope: Scope = Scope(), params: Optional[Params] = None, min_loads: int = 5, top: int = 25) -> pd.DataFrame:
    """Days since the last load against the customer's usual gap between loads (ratio above 1 = overdue for its own rhythm)."""
    f = star.fact_load_trip.sort_values(["customer_id", "load_date"])
    gap = f.groupby("customer_id")["load_date"].diff().dt.days
    a = f.assign(gap=gap).groupby("customer_id").agg(loads=("load_id", "count"), avg_gap_days=("gap", "mean"), last_load_date=("load_date", "max")).reset_index()
    a["days_since_last_load"] = (star.as_of - a["last_load_date"]).dt.days
    a["overdue_ratio"] = sdiv(a["days_since_last_load"], a["avg_gap_days"]).round(2)
    a["avg_gap_days"] = a["avg_gap_days"].round(1)
    a = a[a["loads"] >= min_loads].merge(star.dim_customer[["customer_id", "customer_name"]], on="customer_id", how="left")
    return a.sort_values("overdue_ratio", ascending=False).head(top)[["customer_id", "customer_name", "loads", "avg_gap_days", "days_since_last_load", "overdue_ratio"]].reset_index(drop=True)


def c4_maintenance_due(star: Star, scope: Scope = Scope(), params: Optional[Params] = None, top: int = 25) -> pd.DataFrame:
    """Miles since the last service against the truck's usual miles between services, converted to days by its mileage."""
    f = star.fact_load_trip[star.fact_load_trip["truck_id"].notna()]
    ls = star.fact_maintenance_event.groupby("truck_id").agg(last_service_date=("maintenance_date", "max"), events=("maintenance_id", "count"))
    use = f.groupby("truck_id").agg(total_miles=("miles", "sum"), first_d=("load_date", "min"), last_d=("load_date", "max"))
    j = f.merge(ls.reset_index(), on="truck_id")
    since = j[j["load_date"] > j["last_service_date"]].groupby("truck_id")["miles"].sum().rename("miles_since")
    x = use.join(ls, how="inner").join(since).fillna({"miles_since": 0.0})
    days = (x["last_d"] - x["first_d"]).dt.days + 1
    x["avg_miles_between_service"] = sdiv(x["total_miles"], x["events"]).round()
    x["miles_since_last_service"] = x["miles_since"].round()
    x["miles_per_day"] = sdiv(x["total_miles"], days).round()
    x["predicted_days_to_service"] = sdiv(x["avg_miles_between_service"] - x["miles_since"], x["miles_per_day"]).round()
    return x.reset_index().sort_values("predicted_days_to_service").head(top)[["truck_id", "avg_miles_between_service", "miles_since_last_service", "miles_per_day", "predicted_days_to_service"]].reset_index(drop=True)


def c5_scenario_grid(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Gross profit for rate changes (rows) against fuel price changes (columns), from today's totals. Deterministic what-if arithmetic."""
    o = m_finance(star, scope, params).iloc[0]
    rows = []
    for r in np.round(np.arange(-0.10, 0.2001, 0.05), 2):
        for fz in np.round(np.arange(-0.20, 0.3001, 0.10), 2):
            rev = o["total_revenue"] * (1 + r)
            gp = rev - (o["total_cost"] + o["fuel_cost"] * fz)
            rows.append(dict(rate_change_pct=round(r * 100), fuel_change_pct=round(fz * 100), gross_profit=round(gp), margin_pct=round(float(sdiv(gp, rev)) * 100, 1)))
    return pd.DataFrame(rows)


def c6_fuel_savings(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> pd.DataFrame:
    """Gallons and dollars saved if the fleet reached each target MPG."""
    o = m_finance(star, scope, params).iloc[0]
    price = float(sdiv(o["fuel_cost"], o["fuel_gallons"]))
    rows = []
    for t in (6.5, 7.0, 7.5, 8.0):
        saved = o["fuel_gallons_used"] - o["total_miles"] / t
        rows.append(dict(target_mpg=t, gallons_saved=round(saved), dollars_saved=round(saved * price)))
    return pd.DataFrame(rows)


ANALYSES = {
    "a1_revenue_trend": a1_revenue_trend, "a2_headline": a2_headline, "a3_revenue_by_customer_type": a3_revenue_by_customer_type,
    "a4_pareto": a4_pareto, "a5_fuel_by_state": a5_fuel_by_state, "a6_safety": a6_safety, "a7_network_balance": a7_network_balance,
    "b1_cost_structure": b1_cost_structure, "b2_driver_spread": b2_driver_spread, "b3_fuel_price_variation": b3_fuel_price_variation,
    "b4_ontime_hotspots": b4_ontime_hotspots, "b5_detention_correlation": b5_detention_correlation, "b6_unknown_driver_share": b6_unknown_driver_share,
    "b7_allocation_reconciliation": b7_allocation_reconciliation, "b8_margin_spread": b8_margin_spread,
    "c1_revenue_forecast": c1_revenue_forecast, "c2_seasonality_index": c2_seasonality_index, "c3_churn_risk": c3_churn_risk,
    "c4_maintenance_due": c4_maintenance_due, "c5_scenario_grid": c5_scenario_grid, "c6_fuel_savings": c6_fuel_savings,
}


def run_all(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Dict[str, pd.DataFrame]:
    """Run every analysis; functions that return several tables are flattened to `name.part`."""
    out: Dict[str, pd.DataFrame] = {}
    for name, fn in ANALYSES.items():
        res = fn(star, scope, params)
        if isinstance(res, dict):
            for part, df in res.items():
                out[f"{name}.{part}"] = df
        else:
            out[name] = res
    return out
