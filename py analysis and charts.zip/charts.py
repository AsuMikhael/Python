"""Charts for the seven dashboards (matplotlib, object-oriented API: no pyplot state, safe on servers)."""
from __future__ import annotations

import os
from typing import Callable, Dict, List, Optional

import numpy as np
import pandas as pd
from matplotlib.figure import Figure

from .config import ABC_COLORS, BAD, BORDER, CAUTION, GOOD, LABEL, NO_DATA, PALETTE, TEXT
from .measures import (m_city_network, m_customer_scorecard, m_delivery_by, m_driver_by_tenure, m_driver_scorecard, m_finance, m_finance_by,
                       m_fuel_by, m_fuel_by_state, m_loads_daily, m_maintenance_by, m_margin_bridge, m_revenue_trend, m_route_scorecard,
                       m_safety_by, m_scenario, m_truck_scorecard)
from .params import Params
from .scope import Scope
from .star import Star

NAVY, BLUE, ORANGE, GREEN, RED, PURPLE, SLATE, GOLD = PALETTE


def _fig(title: str, w: float = 9.0, h: float = 4.6, xlabel: str = "", ylabel: str = ""):
    fig = Figure(figsize=(w, h), dpi=110, facecolor="white")
    ax = fig.add_subplot(111)
    ax.set_title(title, loc="left", fontsize=12, fontweight="bold", color=TEXT)
    ax.set_xlabel(xlabel, color=LABEL, fontsize=9)
    ax.set_ylabel(ylabel, color=LABEL, fontsize=9)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(BORDER)
    ax.tick_params(colors=LABEL, labelsize=8)
    ax.grid(axis="y", color=BORDER, linewidth=0.7)
    ax.set_axisbelow(True)
    return fig, ax


def _ticks(ax, labels, every: int = 1, rotate: int = 45):
    idx = list(range(0, len(labels), every))
    ax.set_xticks(idx)
    ax.set_xticklabels([labels[i] for i in idx], rotation=rotate, ha="right")


def _money(x, _=None) -> str:
    return f"${x / 1e6:.1f}M" if abs(x) >= 1e6 else f"${x / 1e3:.0f}K" if abs(x) >= 1e3 else f"${x:.0f}"


def _fmt_money(ax, axis: str = "y"):
    from matplotlib.ticker import FuncFormatter
    (ax.yaxis if axis == "y" else ax.xaxis).set_major_formatter(FuncFormatter(_money))


def _empty(fig, ax, msg="No data in scope"):
    ax.text(0.5, 0.5, msg, ha="center", va="center", color=LABEL, transform=ax.transAxes)
    return fig


# ------------------------------------------------------------------ Executive
def chart_exec_revenue_trend(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_revenue_trend(star, scope, params)
    fig, ax = _fig("Revenue by month vs prior year")
    if t.empty: return _empty(fig, ax)
    x = np.arange(len(t))
    ax.bar(x, t["total_revenue"], color=BLUE, alpha=0.85, label="Revenue")
    ax.plot(x, t["revenue_py"], color=ORANGE, marker="o", markersize=3, linewidth=1.8, label="Prior year")
    _ticks(ax, list(t["year_month"]), every=max(1, len(t) // 18)); _fmt_money(ax); ax.legend(frameon=False, fontsize=8, loc="upper center", ncol=2)
    return fig


def chart_exec_top_customers(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_customer_scorecard(star, scope, params).head(10).iloc[::-1]
    fig, ax = _fig("Top 10 customers by revenue")
    if t.empty: return _empty(fig, ax)
    ax.barh(t["customer_name"].astype(str), t["customer_revenue"], color=[ABC_COLORS.get(c, NAVY) for c in t["abc_class"]])
    _fmt_money(ax, "x"); ax.grid(axis="y", visible=False); ax.grid(axis="x", color=BORDER)
    return fig


def chart_exec_route_scatter(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_route_scorecard(star, scope, params)
    fig, ax = _fig("Route revenue vs margin", xlabel="Revenue", ylabel="Gross margin")
    if t.empty: return _empty(fig, ax)
    ax.scatter(t["route_revenue"], t["gross_margin"], s=18 + t["load_count"] * 0.6, c=t["route_tier_color"], alpha=0.85, edgecolors="white", linewidths=0.5)
    ax.axhline(t["gross_profit"].sum() / t["route_revenue"].sum(), color=SLATE, linestyle="--", linewidth=1)
    _fmt_money(ax, "x"); ax.yaxis.set_major_formatter(lambda v, _: f"{v * 100:.0f}%")
    return fig


def chart_exec_facility_map(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    d = m_delivery_by(star, "facility", scope, params).merge(star.dim_facility.astype({"facility_id": "string"}), left_on="dim_key", right_on="facility_id", how="left")
    fig, ax = _fig("Delivery performance by facility", xlabel="Longitude", ylabel="Latitude")
    if d.empty: return _empty(fig, ax)
    ax.scatter(d["longitude"], d["latitude"], s=40 + d["total_deliveries"] * 0.4, c=d["on_time_status_color"], alpha=0.85, edgecolors="white")
    for _, r in d.iterrows():
        ax.annotate(str(r["city"]), (r["longitude"], r["latitude"]), fontsize=7, color=LABEL, xytext=(4, 4), textcoords="offset points")
    return fig


# ------------------------------------------------------------------ Operations
def chart_ops_loads_daily(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    d = m_loads_daily(star, scope, params)
    fig, ax = _fig("Loads booked per day, with 7-day average")
    if d.empty: return _empty(fig, ax)
    ax.plot(d["load_date"], d["loads_booked"], color=BLUE, alpha=0.35, linewidth=0.8, label="Daily")
    ax.plot(d["load_date"], d["loads_booked_7day_avg"], color=NAVY, linewidth=2, label="7-day average")
    ax.legend(frameon=False, fontsize=8)
    return fig


def chart_ops_ontime_trend(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    p = params or Params()
    d = m_delivery_by(star, "year_month", scope, p)
    fig, ax = _fig("On-time delivery % by month")
    if d.empty: return _empty(fig, ax)
    ax.plot(range(len(d)), d["on_time_pct"], color=NAVY, marker="o", markersize=3)
    ax.axhline(p.get("on_time_target"), color=GREEN, linestyle="--", linewidth=1, label="Target")
    ax.yaxis.set_major_formatter(lambda v, _: f"{v * 100:.0f}%"); _ticks(ax, list(d["dim_label"]), every=max(1, len(d) // 18)); ax.legend(frameon=False, fontsize=8)
    return fig


def chart_ops_detention_hist(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    d = m_delivery_by(star, "detention_bucket", scope, params).sort_values("dim_key")
    fig, ax = _fig("Stops by detention time")
    if d.empty: return _empty(fig, ax)
    ax.bar(d["dim_label"].astype(str), d["stop_count"], color=SLATE)
    return fig


def chart_ops_weekday_heatmap(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    from .datasets import _weekday_month
    d = _weekday_month(star, scope, params or Params())
    fig, ax = _fig("On-time % by weekday and month", w=9, h=3.8)
    if d.empty: return _empty(fig, ax)
    piv = d.pivot_table(index="day_number", columns="month_number", values="on_time_pct")
    im = ax.imshow(piv.to_numpy(dtype=float), aspect="auto", cmap="RdYlGn")
    ax.set_xticks(range(piv.shape[1])); ax.set_xticklabels([str(c) for c in piv.columns]); ax.set_yticks(range(piv.shape[0]))
    ax.set_yticklabels(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][: piv.shape[0]]); ax.grid(False)
    fig.colorbar(im, ax=ax, format=lambda v, _: f"{v * 100:.0f}%")
    return fig


# ------------------------------------------------------------------ Drivers
def chart_drivers_scatter(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_driver_scorecard(star, scope, params)
    t = t[t["low_miles_filter"] == 1]
    fig, ax = _fig("Driver quadrant: on-time vs fuel efficiency", xlabel="On-time %", ylabel="MPG")
    if t.empty: return _empty(fig, ax)
    ax.scatter(t["driver_on_time_pct"], t["avg_mpg"], s=20 + t["total_miles"] / t["total_miles"].max() * 140, c=t["driver_score_color"], alpha=0.85, edgecolors="white")
    ax.axvline(t["driver_on_time_pct"].median(), color=SLATE, linestyle="--", linewidth=0.8); ax.axhline(t["avg_mpg"].median(), color=SLATE, linestyle="--", linewidth=0.8)
    ax.xaxis.set_major_formatter(lambda v, _: f"{v * 100:.0f}%")
    return fig


def chart_drivers_top(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_driver_scorecard(star, scope, params)
    t = t[t["top_n_driver_flag"] == 1].sort_values("revenue_trip_based").tail(15)
    fig, ax = _fig("Top drivers by revenue")
    if t.empty: return _empty(fig, ax)
    ax.barh(t["driver_name"].astype(str), t["revenue_trip_based"], color=NAVY); _fmt_money(ax, "x"); ax.grid(axis="y", visible=False)
    return fig


def chart_drivers_tenure(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_driver_by_tenure(star, scope, params)
    fig, ax = _fig("Driver score by tenure")
    if t.empty: return _empty(fig, ax)
    ax.bar(t["tenure_band"].astype(str), t["driver_score"], color=t["driver_score_color"]); ax.set_ylim(0, 100)
    return fig


# ------------------------------------------------------------------ Fleet
def chart_fleet_cost_by_month(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_maintenance_by(star, "year_month", scope, params)
    fig, ax = _fig("Maintenance cost by month")
    if t.empty: return _empty(fig, ax)
    x = np.arange(len(t))
    ax.bar(x, t["labor_cost"], color=NAVY, label="Labor"); ax.bar(x, t["parts_cost"], bottom=t["labor_cost"], color=ORANGE, label="Parts")
    _ticks(ax, list(t["dim_label"]), every=max(1, len(t) // 18)); _fmt_money(ax); ax.legend(frameon=False, fontsize=8)
    return fig


def chart_fleet_cost_by_type(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_maintenance_by(star, "maintenance_type", scope, params).sort_values("maintenance_cost")
    fig, ax = _fig("Cost by maintenance type")
    if t.empty: return _empty(fig, ax)
    ax.barh(t["dim_label"].astype(str), t["maintenance_cost"], color=BLUE); _fmt_money(ax, "x"); ax.grid(axis="y", visible=False)
    return fig


def chart_fleet_age_scatter(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_truck_scorecard(star, scope, params).dropna(subset=["truck_age", "maint_cost_per_mile_actual"])
    fig, ax = _fig("Truck age vs maintenance cost per mile", xlabel="Truck age (years)", ylabel="Maintenance cost per mile")
    if t.empty: return _empty(fig, ax)
    ax.scatter(t["truck_age"].astype(float), t["maint_cost_per_mile_actual"], s=30 + t["maintenance_cost"].fillna(0) / t["maintenance_cost"].max() * 160,
               c=t["cost_per_mile_color"], alpha=0.85, edgecolors="white")
    return fig


# ------------------------------------------------------------------ Fuel and safety
def chart_fuel_trend(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_fuel_by(star, "year_month", scope, params)
    fig, ax = _fig("Fuel cost and price per gallon by month")
    if t.empty: return _empty(fig, ax)
    x = np.arange(len(t))
    ax.bar(x, t["fuel_cost"], color=BLUE, alpha=0.8); _fmt_money(ax)
    ax2 = ax.twinx(); ax2.plot(x, t["avg_price_per_gallon"], color=ORANGE, marker="o", markersize=3, linewidth=1.8)
    ax2.set_ylabel("$ per gallon", color=LABEL, fontsize=9); ax2.tick_params(colors=LABEL, labelsize=8)
    for s in ("top",): ax2.spines[s].set_visible(False)
    _ticks(ax, list(t["dim_label"]), every=max(1, len(t) // 18))
    return fig


def chart_fuel_by_state(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_fuel_by_state(star, scope, params).head(15).iloc[::-1]
    fig, ax = _fig("Fuel spend by state")
    if t.empty: return _empty(fig, ax)
    ax.barh(t["location_state"].astype(str), t["fuel_cost"], color=NAVY); _fmt_money(ax, "x"); ax.grid(axis="y", visible=False)
    return fig


def chart_safety_by_type(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_safety_by(star, "incident_type", scope, params).sort_values("safety_incidents")
    fig, ax = _fig("Incidents by type")
    if t.empty: return _empty(fig, ax)
    ax.barh(t["dim_label"].astype(str), t["safety_incidents"], color=RED); ax.grid(axis="y", visible=False)
    return fig


def chart_safety_trend(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_safety_by(star, "year_month", scope, params)
    t = t[t["dim_key"].notna()]
    fig, ax = _fig("Incidents and at-fault share")
    if t.empty: return _empty(fig, ax)
    x = np.arange(len(t))
    ax.bar(x, t["safety_incidents"], color=SLATE)
    ax2 = ax.twinx(); ax2.plot(x, t["at_fault_pct"], color=RED, marker="o", markersize=3); ax2.set_ylim(0, 1)
    ax2.yaxis.set_major_formatter(lambda v, _: f"{v * 100:.0f}%"); ax2.tick_params(colors=LABEL, labelsize=8); ax2.spines["top"].set_visible(False)
    _ticks(ax, list(t["dim_label"]), every=max(1, len(t) // 18))
    return fig


# ------------------------------------------------------------------ Customers
def chart_customers_pareto(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_customer_scorecard(star, scope, params)
    fig, ax = _fig("Customer revenue and cumulative revenue %")
    if t.empty: return _empty(fig, ax)
    x = np.arange(len(t))
    ax.bar(x, t["customer_revenue"], color=[ABC_COLORS.get(c, NAVY) for c in t["abc_class"]]); _fmt_money(ax)
    ax2 = ax.twinx(); ax2.plot(x, t["cumulative_revenue_pct"], color=GOLD, linewidth=2); ax2.set_ylim(0, 1.02)
    ax2.axhline(0.8, color=SLATE, linestyle="--", linewidth=0.8); ax2.yaxis.set_major_formatter(lambda v, _: f"{v * 100:.0f}%")
    ax2.tick_params(colors=LABEL, labelsize=8); ax2.spines["top"].set_visible(False)
    ax.set_xticks([]);
    return fig


def chart_customers_quadrant(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_customer_scorecard(star, scope, params)
    fig, ax = _fig("Customer revenue vs margin", xlabel="Revenue", ylabel="Margin")
    if t.empty: return _empty(fig, ax)
    ax.scatter(t["customer_revenue"], t["customer_margin_pct"], s=20 + t["load_count"] * 0.5, c=t["abc_color"], alpha=0.85, edgecolors="white")
    _fmt_money(ax, "x"); ax.yaxis.set_major_formatter(lambda v, _: f"{v * 100:.0f}%")
    return fig


# ------------------------------------------------------------------ Routes
def chart_routes_waterfall(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_margin_bridge(star, scope, params)
    fig, ax = _fig("From revenue to gross profit")
    v = t["margin_bridge_value"].astype(float).to_list()
    if not v or np.isnan(v[0]): return _empty(fig, ax)
    rev, fuel, maint, gp = v
    ax.bar(0, rev, color=NAVY); ax.bar(1, fuel, bottom=rev, color=RED); ax.bar(2, maint, bottom=rev + fuel, color=RED); ax.bar(3, gp, color=GREEN)
    ax.set_xticks(range(4)); ax.set_xticklabels(["Revenue", "Fuel", "Maintenance", "Gross profit"]); _fmt_money(ax)
    return fig


def chart_routes_lane_heatmap(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    from .measures import m_lane_matrix
    t = m_lane_matrix(star, scope, params)
    fig, ax = _fig("Gross margin by lane", w=9, h=5.2)
    if t.empty: return _empty(fig, ax)
    piv = t.pivot_table(index="origin_city", columns="destination_city", values="gross_margin")
    im = ax.imshow(piv.to_numpy(dtype=float), aspect="auto", cmap="RdYlGn")
    ax.set_xticks(range(piv.shape[1])); ax.set_xticklabels(piv.columns, rotation=60, ha="right"); ax.set_yticks(range(piv.shape[0])); ax.set_yticklabels(piv.index); ax.grid(False)
    fig.colorbar(im, ax=ax, format=lambda v, _: f"{v * 100:.0f}%"); fig.subplots_adjust(bottom=0.25)
    return fig


def chart_routes_network(star: Star, scope: Scope = Scope(), params: Optional[Params] = None) -> Figure:
    t = m_city_network(star, scope, params).sort_values("outbound_loads")
    fig, ax = _fig("Loads out vs in by city")
    if t.empty: return _empty(fig, ax)
    y = np.arange(len(t))
    ax.barh(y + 0.2, t["outbound_loads"], height=0.4, color=NAVY, label="Outbound"); ax.barh(y - 0.2, t["inbound_loads"], height=0.4, color=GOLD, label="Inbound")
    ax.set_yticks(y); ax.set_yticklabels(t["city"]); ax.grid(axis="y", visible=False); ax.legend(frameon=False, fontsize=8)
    return fig


CHARTS: Dict[str, Callable[..., Figure]] = {
    "exec_revenue_trend": chart_exec_revenue_trend, "exec_top_customers": chart_exec_top_customers, "exec_route_scatter": chart_exec_route_scatter,
    "exec_facility_map": chart_exec_facility_map, "ops_loads_daily": chart_ops_loads_daily, "ops_ontime_trend": chart_ops_ontime_trend,
    "ops_detention_hist": chart_ops_detention_hist, "ops_weekday_heatmap": chart_ops_weekday_heatmap, "drivers_scatter": chart_drivers_scatter,
    "drivers_top": chart_drivers_top, "drivers_tenure": chart_drivers_tenure, "fleet_cost_by_month": chart_fleet_cost_by_month,
    "fleet_cost_by_type": chart_fleet_cost_by_type, "fleet_age_scatter": chart_fleet_age_scatter, "fuel_trend": chart_fuel_trend,
    "fuel_by_state": chart_fuel_by_state, "safety_by_type": chart_safety_by_type, "safety_trend": chart_safety_trend,
    "customers_pareto": chart_customers_pareto, "customers_quadrant": chart_customers_quadrant, "routes_waterfall": chart_routes_waterfall,
    "routes_lane_heatmap": chart_routes_lane_heatmap, "routes_network": chart_routes_network,
}


def render_all(star: Star, directory: str, scope: Scope = Scope(), params: Optional[Params] = None, dpi: int = 110) -> List[str]:
    """Save every chart as a PNG and return the paths."""
    os.makedirs(directory, exist_ok=True)
    paths = []
    for name, fn in CHARTS.items():
        fig = fn(star, scope, params)
        fig.tight_layout() if name != "routes_lane_heatmap" else None
        path = os.path.join(directory, f"{name}.png")
        fig.savefig(path, dpi=dpi, facecolor="white")
        paths.append(path)
    return paths
