"""Command line: `python -m logistics_analytics <command>` (or `logistics <command>` once installed)."""
from __future__ import annotations

import argparse
import os
import sys
from typing import List, Optional

import pandas as pd

from . import __version__
from .params import Params
from .scope import Scope


def _scope_args(p: argparse.ArgumentParser) -> None:
    g = p.add_argument_group("filters (slicers); omit for All")
    for name, helptext in [("start", "first load date (YYYY-MM-DD)"), ("end", "last load date (YYYY-MM-DD)"), ("customer", "customer id"),
                           ("route", "route id"), ("driver", "driver id"), ("truck", "truck id"), ("booking", "booking type"),
                           ("facility", "facility id (deliveries)"), ("incident-type", "incident type (safety)"), ("state", "state (fuel)"),
                           ("maintenance-type", "maintenance type")]:
        g.add_argument(f"--{name}", default=None, help=helptext)
    p.add_argument("--param", action="append", default=[], metavar="NAME=VALUE", help="what-if parameter, repeatable (for example top_n=18)")


def _scope(a: argparse.Namespace) -> Scope:
    return Scope(start=a.start, end=a.end, customer=a.customer, route=a.route, driver=a.driver, truck=a.truck, booking=a.booking,
                 facility=a.facility, incident_type=a.incident_type, state=a.state, maintenance_type=a.maintenance_type)


def _params(a: argparse.Namespace) -> Params:
    p = Params()
    for item in a.param:
        if "=" not in item:
            raise SystemExit(f"--param expects NAME=VALUE, got {item!r}")
        k, v = item.split("=", 1)
        p.set(k.strip(), float(v))
    return p


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="logistics", description="Logistics analytics: build the star, run measures, checks, analysis and charts.")
    p.add_argument("--version", action="version", version=f"logistics-analytics {__version__}")
    sub = p.add_subparsers(dest="command", required=True)

    d = sub.add_parser("demo", help="generate synthetic data and run the whole pipeline")
    d.add_argument("--out", default="demo_output"); d.add_argument("--seed", type=int, default=7); d.add_argument("--loads", type=int, default=1500)

    b = sub.add_parser("build", help="build the star from CSV files or a SQLite database and save it")
    b.add_argument("--source", help="directory with the 14 source CSV files"); b.add_argument("--sqlite", help="path to a SQLite database holding the source tables")
    b.add_argument("--out", required=True, help="directory for the star"); b.add_argument("--format", choices=["csv", "parquet"], default="csv")

    c = sub.add_parser("check", help="data quality, consistency and (optionally) reconciliation checks")
    c.add_argument("--source", help="source CSV directory (enables the data-quality checks)"); c.add_argument("--star", help="saved star directory")
    c.add_argument("--reference", action="store_true", help="also reconcile against the Power BI reference figures")

    ds = sub.add_parser("datasets", help="export one dataset per dashboard visual")
    ds.add_argument("--star", required=True); ds.add_argument("--out", required=True); ds.add_argument("--format", choices=["csv", "xlsx"], default="csv")
    ds.add_argument("--only", help="dataset name prefix, for example v_exec_"); _scope_args(ds)

    an = sub.add_parser("analyze", help="run the descriptive, diagnostic and predictive analyses")
    an.add_argument("--star", required=True); an.add_argument("--out", required=True); _scope_args(an)

    ch = sub.add_parser("charts", help="render the dashboard charts as PNG files")
    ch.add_argument("--star", required=True); ch.add_argument("--out", required=True); _scope_args(ch)

    m = sub.add_parser("measure", help="run one measure function and print the result")
    m.add_argument("name", help="function name, for example m_finance"); m.add_argument("--star", required=True)
    m.add_argument("--dimension", help="for the m_*_by functions"); m.add_argument("--rows", type=int, default=30); _scope_args(m)

    cat = sub.add_parser("catalogue", help="write the DAX-to-Python measure catalogue as markdown")
    cat.add_argument("--star", required=True); cat.add_argument("--out", required=True)
    return p


def _load_star(path: str):
    from .star import load_star
    return load_star(path)


def _print(df: pd.DataFrame, rows: int = 30) -> None:
    with pd.option_context("display.width", 200, "display.max_columns", 40, "display.max_colwidth", 40):
        print(df.head(rows).to_string(index=False))


def cmd_demo(a) -> int:
    from . import analysis, charts, checks
    from .datasets import build_datasets, export_datasets
    from .loaders import save_tables
    from .star import build_star, save_star
    from .synthetic import make_synthetic_source
    src = make_synthetic_source(seed=a.seed, n_loads=a.loads)
    save_tables(src, os.path.join(a.out, "source"))
    star = build_star(src)
    save_star(star, os.path.join(a.out, "star"))
    ds = build_datasets(star)
    export_datasets(ds, os.path.join(a.out, "datasets"))
    res = analysis.run_all(star)
    os.makedirs(os.path.join(a.out, "analysis"), exist_ok=True)
    for name, df in res.items():
        df.to_csv(os.path.join(a.out, "analysis", f"{name}.csv"), index=False)
    paths = charts.render_all(star, os.path.join(a.out, "charts"))
    cc = checks.consistency_checks(star)
    print(f"Synthetic source: {sum(len(t) for t in src.values()):,} rows in 14 tables")
    print(f"Star: {len(star.tables())} tables | datasets: {len(ds)} | analyses: {len(res)} | charts: {len(paths)}")
    print(f"Consistency checks passed: {int(cc['passed'].sum())} of {len(cc)}")
    print(f"Output written to {os.path.abspath(a.out)}")
    return 0 if cc["passed"].all() else 1


def cmd_build(a) -> int:
    from .loaders import load_csv_dir, load_database
    from .star import build_star, save_star
    if bool(a.source) == bool(a.sqlite):
        raise SystemExit("Give exactly one of --source or --sqlite")
    if a.source:
        src = load_csv_dir(a.source)
    else:
        import sqlite3
        con = sqlite3.connect(a.sqlite)
        try:
            src = load_database(con)
        finally:
            con.close()
    star = build_star(src)
    save_star(star, a.out, a.format)
    _print(star.summary())
    print(f"Star saved to {os.path.abspath(a.out)} (as of {star.as_of.date()})")
    return 0


def cmd_check(a) -> int:
    from . import checks
    from .loaders import load_csv_dir
    from .star import build_star
    if a.source:
        src = load_csv_dir(a.source)
        star = build_star(src)
        print("\nData quality"); _print(checks.data_quality(src, star))
    elif a.star:
        star = _load_star(a.star)
    else:
        raise SystemExit("Give --source or --star")
    print("\nOrphan keys"); _print(checks.orphan_check(star))
    cc = checks.consistency_checks(star)
    print("\nConsistency checks"); _print(cc[["check", "passed"]], 100)
    ok = bool(cc["passed"].all())
    if a.reference:
        rc = checks.reconcile(star)
        print("\nReconciliation with the Power BI reference figures"); _print(rc, 100)
        ok = ok and bool(rc["passed"].all())
    print("\nRESULT:", "all checks passed" if ok else "some checks failed")
    return 0 if ok else 1


def cmd_datasets(a) -> int:
    from .datasets import build_datasets, export_datasets
    ds = build_datasets(_load_star(a.star), _scope(a), _params(a), only=a.only)
    path = export_datasets(ds, a.out, a.format)
    print(f"{len(ds)} datasets written to {os.path.abspath(path)}")
    return 0


def cmd_analyze(a) -> int:
    from . import analysis
    res = analysis.run_all(_load_star(a.star), _scope(a), _params(a))
    os.makedirs(a.out, exist_ok=True)
    for name, df in res.items():
        df.to_csv(os.path.join(a.out, f"{name}.csv"), index=False)
    print(f"{len(res)} analysis tables written to {os.path.abspath(a.out)}")
    return 0


def cmd_charts(a) -> int:
    from . import charts
    paths = charts.render_all(_load_star(a.star), a.out, _scope(a), _params(a))
    print(f"{len(paths)} charts written to {os.path.abspath(a.out)}")
    return 0


def cmd_measure(a) -> int:
    from .measures import MEASURE_FUNCTIONS
    if a.name not in MEASURE_FUNCTIONS:
        raise SystemExit(f"Unknown function {a.name!r}. Available: {', '.join(MEASURE_FUNCTIONS)}")
    fn = MEASURE_FUNCTIONS[a.name]
    star = _load_star(a.star)
    out = fn(star, a.dimension, _scope(a), _params(a)) if a.name.endswith("_by") else fn(star, _scope(a), _params(a))
    _print(out, a.rows)
    return 0


def cmd_catalogue(a) -> int:
    from .catalogue import coverage, to_markdown
    cv = coverage(_load_star(a.star))
    with open(a.out, "w", encoding="utf-8") as fh:
        fh.write(to_markdown(cv))
    print(f"{len(cv)} measures; unmapped: {int(cv['function'].isna().sum())}; written to {a.out}")
    return 0 if cv["function"].notna().all() else 1


_COMMANDS = {"demo": cmd_demo, "build": cmd_build, "check": cmd_check, "datasets": cmd_datasets, "analyze": cmd_analyze,
             "charts": cmd_charts, "measure": cmd_measure, "catalogue": cmd_catalogue}


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return _COMMANDS[args.command](args)
    except (FileNotFoundError, ValueError, KeyError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
