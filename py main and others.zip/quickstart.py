"""Quick start: build the star from the 14 CSV files and use the measures, checks, analysis and charts.

Run from the repository root:  PYTHONPATH=src python examples/quickstart.py [path/to/csv/folder]
Without an argument it uses synthetic data so you can see everything working.
"""
import sys

from logistics_analytics import analysis, charts, checks
from logistics_analytics.loaders import load_csv_dir
from logistics_analytics.measures import m_customer_scorecard, m_finance, m_finance_by, m_kpi_exec
from logistics_analytics.params import Params
from logistics_analytics.scope import Scope
from logistics_analytics.star import build_star
from logistics_analytics.synthetic import make_synthetic_source

source = load_csv_dir(sys.argv[1]) if len(sys.argv) > 1 else make_synthetic_source()
star = build_star(source)
print(star.summary().to_string(index=False))

# 1. Measures: filters are a Scope (None = All); what-if parameters are a Params object
print(m_finance(star)[["total_revenue", "gross_profit", "gross_margin", "load_count"]])
year = Scope(start="2024-01-01", end="2024-12-31")
print(m_kpi_exec(star, year)[["total_revenue", "revenue_yoy_pct", "on_time_pct", "headline"]])
print(m_finance_by(star, "quarter", year)[["dim_label", "total_revenue", "gross_margin"]])
print(m_customer_scorecard(star, params=Params(top_n=5)).head())

# 2. Checks
print(checks.consistency_checks(star)[["check", "passed"]])

# 3. Analysis and charts
print(analysis.c1_revenue_forecast(star))
charts.render_all(star, "output/charts")
print("charts written to output/charts")
